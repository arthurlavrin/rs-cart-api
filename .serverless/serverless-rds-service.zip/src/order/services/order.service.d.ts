import { Order } from '../../database/entities/order.entity';
import { Repository } from 'typeorm';
export declare class OrderService {
    private readonly orderRepository;
    constructor(orderRepository: Repository<Order>);
    findById(orderId: string): Promise<Order>;
    create(data: any): Promise<Order[]>;
    update(orderId: any, data: any): Promise<Order[]>;
}
