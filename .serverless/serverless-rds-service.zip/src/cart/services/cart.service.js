"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const cart_item_entity_1 = require("../../database/entities/cart-item.entity");
const cart_entity_1 = require("../../database/entities/cart.entity");
const typeorm_2 = require("typeorm");
const uuid_1 = require("uuid");
let CartService = class CartService {
    constructor(cartRepository, cartItemRepository) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
    }
    async findByUserId(userId) {
        const userCart = await this.cartRepository.findOne({
            where: { user_id: userId, status: cart_entity_1.CartStatus.OPEN },
            relations: ['items'],
        });
        return userCart;
    }
    async createByUserId(userId) {
        const userCart = {
            id: uuid_1.v4(),
            user_id: userId,
            items: [],
            createdAt: new Date(),
            updatedAt: new Date(),
            status: cart_entity_1.CartStatus.OPEN,
        };
        return this.cartRepository.save(userCart);
    }
    async findOrCreateByUserId(userId) {
        const userCart = await this.findByUserId(userId);
        if (userCart) {
            return userCart;
        }
        return this.createByUserId(userId);
    }
    async updateByUserId(userId, { items }) {
        const cart = await this.findOrCreateByUserId(userId);
        const cartItems = await this.cartItemRepository.findByIds(items.map(item => item.cart_id));
        const updatedCart = Object.assign(Object.assign({}, cart), { updatedAt: new Date(), items: cartItems });
        return this.cartRepository.save(updatedCart);
    }
    async removeByUserId(userId) {
        const card = await this.findByUserId(userId);
        const cardItem = await this.cartItemRepository.findOne({
            where: { cart_id: card.id },
        });
        if (cardItem) {
            await this.cartItemRepository.remove(cardItem);
        }
        await this.cartRepository.remove(card);
    }
};
CartService = __decorate([
    common_1.Injectable(),
    __param(0, typeorm_1.InjectRepository(cart_entity_1.Cart)),
    __param(1, typeorm_1.InjectRepository(cart_item_entity_1.CartItem)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], CartService);
exports.CartService = CartService;
//# sourceMappingURL=cart.service.js.map