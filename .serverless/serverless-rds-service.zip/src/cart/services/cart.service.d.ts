import { CartItem } from '../../database/entities/cart-item.entity';
import { Cart, CartStatus } from '../../database/entities/cart.entity';
import { Repository } from 'typeorm';
export declare class CartService {
    private readonly cartRepository;
    private readonly cartItemRepository;
    constructor(cartRepository: Repository<Cart>, cartItemRepository: Repository<CartItem>);
    findByUserId(userId: string): Promise<Cart>;
    createByUserId(userId: string): Promise<{
        id: any;
        user_id: string;
        items: any[];
        createdAt: Date;
        updatedAt: Date;
        status: CartStatus;
    } & Cart>;
    findOrCreateByUserId(userId: string): Promise<Cart>;
    updateByUserId(userId: string, { items }: Cart): Promise<Cart>;
    removeByUserId(userId: any): Promise<void>;
}
