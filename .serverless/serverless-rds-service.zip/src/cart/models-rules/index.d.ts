import { Cart as CartModel } from '../models';
import { Product } from '../../database/entities/product.entity';
import { Cart } from '../../database/entities/cart.entity';
export declare function calculateCartTotal(cart: Partial<CartModel>): number;
export declare const mergeCartWithProducts: (cart: Cart, products: Product[]) => {
    items: {
        product: Product;
        cart_id: string;
        product_id: string;
        cart: Cart;
        count: number;
    }[];
    id: string;
    user_id: string;
    createdAt: Date;
    updatedAt: Date;
    status: import("../../database/entities/cart.entity").CartStatus;
};
