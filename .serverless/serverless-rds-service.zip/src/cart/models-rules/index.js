"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeCartWithProducts = exports.calculateCartTotal = void 0;
function calculateCartTotal(cart) {
    var _a;
    return cart
        ? (_a = cart.items) === null || _a === void 0 ? void 0 : _a.reduce((acc, { product: { price }, count }) => {
            return (acc += price * count);
        }, 0) : 0;
}
exports.calculateCartTotal = calculateCartTotal;
exports.mergeCartWithProducts = (cart, products) => (Object.assign(Object.assign({}, cart), { items: cart.items.map(item => (Object.assign(Object.assign({}, item), { product: products.find(product => product.id === item.product_id) }))) }));
//# sourceMappingURL=index.js.map