import { HttpStatus } from '@nestjs/common';
import { ProductService } from '../product/services';
import { OrderService } from '../order';
import { AppRequest } from '../shared';
import { CartService } from './services';
export declare class CartController {
    private cartService;
    private orderService;
    private productService;
    constructor(cartService: CartService, orderService: OrderService, productService: ProductService);
    findUserCart(req: AppRequest): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            cart: import("../database/entities/cart.entity").Cart;
            total: number;
        };
    }>;
    updateUserCart(req: AppRequest, body: any): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: {
            cart: import("../database/entities/cart.entity").Cart;
            total: number;
        };
    }>;
    clearUserCart(req: AppRequest): {
        statusCode: HttpStatus;
        message: string;
    };
    checkout(req: AppRequest, body: any): Promise<{
        statusCode: HttpStatus;
        message: string;
        data?: undefined;
    } | {
        statusCode: HttpStatus;
        message: string;
        data: {
            order: import("../database/entities/order.entity").Order[];
        };
    }>;
}
