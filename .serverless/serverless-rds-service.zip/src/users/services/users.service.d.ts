import { User } from '../../database/entities/user.entity';
import { Repository } from 'typeorm';
export declare class UsersService {
    private readonly userRepository;
    constructor(userRepository: Repository<User>);
    findOne(userName: string): Promise<User>;
    createOne({ name, password }: Partial<User>): Promise<User>;
}
