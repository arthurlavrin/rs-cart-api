"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserIdFromRequest = void 0;
function getUserIdFromRequest(request) {
    var _a;
    return (_a = request.query) === null || _a === void 0 ? void 0 : _a.userId;
}
exports.getUserIdFromRequest = getUserIdFromRequest;
//# sourceMappingURL=index.js.map