"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var product_service_1 = require("./product.service");
Object.defineProperty(exports, "ProductService", { enumerable: true, get: function () { return product_service_1.ProductService; } });
//# sourceMappingURL=index.js.map