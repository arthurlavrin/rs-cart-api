import { Repository } from 'typeorm';
import { Product } from '../../database/entities/product.entity';
export declare class ProductService {
    private readonly productRepository;
    constructor(productRepository: Repository<Product>);
    findProducts(ids: string[]): Promise<Product[]>;
}
