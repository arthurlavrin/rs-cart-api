"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var _a, _b, _c, _d;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const cart_item_entity_1 = require("./entities/cart-item.entity");
const cart_entity_1 = require("./entities/cart.entity");
const order_entity_1 = require("./entities/order.entity");
const product_entity_1 = require("./entities/product.entity");
const user_entity_1 = require("./entities/user.entity");
let DatabaseModule = class DatabaseModule {
};
DatabaseModule = __decorate([
    common_1.Module({
        imports: [
            typeorm_1.TypeOrmModule.forRoot({
                type: 'postgres',
                host: (_a = process.env.databaseHost) !== null && _a !== void 0 ? _a : 'shop-database.c4zorjipzakd.eu-north-1.rds.amazonaws.com',
                port: 5432,
                username: (_b = process.env.username) !== null && _b !== void 0 ? _b : 'romasaldan',
                password: (_c = process.env.userPassword) !== null && _c !== void 0 ? _c : 'math1992romaka',
                database: (_d = process.env.database) !== null && _d !== void 0 ? _d : 'romasaldan_database',
                ssl: {
                    rejectUnauthorized: false,
                    ca: 'rds-ca-2019',
                },
                synchronize: true,
                autoLoadEntities: true,
                logging: true,
            }),
            typeorm_1.TypeOrmModule.forFeature([cart_entity_1.Cart, cart_item_entity_1.CartItem, order_entity_1.Order, product_entity_1.Product, user_entity_1.User]),
        ],
        exports: [typeorm_1.TypeOrmModule],
    })
], DatabaseModule);
exports.DatabaseModule = DatabaseModule;
//# sourceMappingURL=database.module.js.map