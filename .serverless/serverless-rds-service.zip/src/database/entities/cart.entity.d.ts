import { CartItem } from './cart-item.entity';
export declare enum CartStatus {
    OPEN = "OPEN",
    ORDERED = "ORDERED"
}
export declare class Cart {
    id: string;
    user_id: string;
    items: CartItem[];
    createdAt: Date;
    updatedAt: Date;
    status: CartStatus;
}
