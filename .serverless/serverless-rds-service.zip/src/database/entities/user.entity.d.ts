export declare class User {
    id: string;
    name: string;
    password: string;
}
