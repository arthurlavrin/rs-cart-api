export declare class DatabaseModule {
}
